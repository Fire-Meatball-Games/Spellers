using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkinDataBase
{
    private List<SkinInfo> hats;
    private List<SkinInfo> suits;
}
